# Atlantic Core

Atlantic core is an HCF core made by Scifi, taken over by me. I purchased rights to this core to release to the community so that people can stop selling iHCF forks.

## Installation

Super straight forward, put this on the compiled jar onto the server, throw on ProtocolLib, WorldEdit, and Vault.

## Code

Code looks bad? Gonna cry about it? Aw well, don't use it, I really don't care. This is here so people can stop selling iHCF forks. (Although I will admit, some are better than others)

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## Found a bug?
Report it in the issue section and I might fix it

## License
[GPL-3.0](https://github.com/DaddyImPregnant/Atlantic/blob/master/LICENSE)
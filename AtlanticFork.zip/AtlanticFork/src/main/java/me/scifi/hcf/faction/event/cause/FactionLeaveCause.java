package me.scifi.hcf.faction.event.cause;

public enum FactionLeaveCause {

    KICK, LEAVE, DISBAND
}
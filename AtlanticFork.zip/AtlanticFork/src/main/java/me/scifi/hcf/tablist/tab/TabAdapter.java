package me.scifi.hcf.tablist.tab;

import org.bukkit.entity.Player;

public interface TabAdapter {

    TabTemplate getTemplate(Player player);

}

package me.scifi.hcf.faction.event.cause;

public enum ClaimChangeCause {

    UNCLAIM, CLAIM, RESIZE
}
